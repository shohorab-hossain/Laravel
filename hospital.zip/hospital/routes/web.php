<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Homecontroller;
use App\Http\Controllers\Admincontroller;
use App\Http\Controllers\About_uscontroller;
use App\Http\Controllers\Doctorcontroller;
use App\Http\Controllers\Newscontroller;
use App\Http\Controllers\Contactcontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/',[Homecontroller::class,'index']);
Route::get('/home',[Homecontroller::class,'redirect']);
Route::get('/about',[About_uscontroller::class,'about']);
Route::get('/doctor',[Doctorcontroller::class,'doctor']);
Route::get('/news',[Newscontroller::class,'news']);
Route::get('/contact',[Contactcontroller::class,'contact']);

Route::get('/add_doctor_view',[Admincontroller::class,'addview']);
Route::post('/upload_doctor',[Admincontroller::class,'upload']);
Route::post('/appointment',[Homecontroller::class,'appointment']);
Route::get('/myappointment',[Homecontroller::class,'myappointment']);
Route::get('/cancle_appoint/{id}',[Homecontroller::class,'cancle_appoint']);
Route::get('/approve/{id}',[Admincontroller::class,'approved']);
Route::get('/deletedoctor/{id}',[Admincontroller::class,'deletedoctor']);
Route::get('/updatedoctor/{id}',[Admincontroller::class,'updatedoctor']);
Route::get('/showappointment',[Admincontroller::class,'showappointment']);
Route::get('/showdoctor',[Admincontroller::class,'showdoctor']);
Route::post('/editdoctor/{id}',[Admincontroller::class,'editdoctor']);

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
