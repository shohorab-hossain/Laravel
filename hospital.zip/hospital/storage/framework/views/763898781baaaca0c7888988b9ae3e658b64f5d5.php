<!DOCTYPE html>
<html lang="en">
  <head>

  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  border: 1px solid black;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
  color:black;
}

tr {
  background-color: #fff;
}
</style>
    
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
      <div class="container-fluid ">
<div class="container">        
<table>
  <tr>
    <th>Doctor Name</th>
    <th>Phone</th>
    <th>Speciality</th>
    <th>Room No</th>
    <th>Image</th>
    <th>Delete</th>
    <th>Update</th>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($doctor->name); ?></td>
    <td><?php echo e($doctor->phone); ?></td>
    <td><?php echo e($doctor->specility); ?></td>
    <td><?php echo e($doctor->room); ?></td>
    <td><img height="100px" width="100px" src="doctorimage/<?php echo e($doctor->image); ?>"></td>
    <td><a class="btn btn-danger" onclick="return confirm('are you sure to delete this!!')" href="<?php echo e(url('deletedoctor',$doctor->id)); ?>">Delete</a></td>
    <td><a class="btn btn-primary" onclick="return confirm('are you sure to update this!!')" href="<?php echo e(url('updatedoctor',$doctor->id)); ?>">Update</a></td>
</tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
      

    <!-- container-scroller -->
    <!-- plugins:js -->
      <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\hospital\resources\views/admin/showdoctor.blade.php ENDPATH**/ ?>