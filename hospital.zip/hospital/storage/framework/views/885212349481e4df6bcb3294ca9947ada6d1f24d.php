<!DOCTYPE html>
<html lang="en">
  <head>
  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  border: 1px solid black;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
  color:black;
}

tr {
  background-color: #fff;
}
</style>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="container-fluid">
<div class="container">        
<table>
  <tr>
    <th>name</th>
    <th>email</th>
    <th>phone</th>
    <th>Doctor name</th>
    <th>Date</th>
    <th>Message</th>
    <th>Status</th>
    <th>Cancle</th>
    <th>Approved</th>
  </tr>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appoints): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr >
    <td><?php echo e($appoints->name); ?></td>
    <td><?php echo e($appoints->email); ?></td>
    <td><?php echo e($appoints->phone); ?></td>
    <td><?php echo e($appoints->doctor); ?></td>
    <td><?php echo e($appoints->date); ?></td>
    <td><?php echo e($appoints->message); ?></td>
    <td><?php echo e($appoints->status); ?></td>
    <td><a class="btn btn-danger" onclick="return confirm('are you sure to delete this!!')" href="<?php echo e(url('cancle_appoint',$appoints->id)); ?>">Cancle</a></td>
    <td><a class="btn btn-success" onclick="return confirm('are you sure to Approve this!!')" href="<?php echo e(url('approve',$appoints->id)); ?>">Approve</a></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</div>

    <!-- container-scroller -->
    <!-- plugins:js -->
      <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\hospital\resources\views/admin/showappointment.blade.php ENDPATH**/ ?>