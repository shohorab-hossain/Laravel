<!DOCTYPE html>
<html lang="en">
  <head>
    <base href="/public">
  <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
  color:black;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  /* background-color: #f2f2f2; */
  padding: 20px;
}
</style>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="container-fluid page-body-wrapper">
      <div class="container">

          <!-- <?php if(session()->has('message')): ?>
           
          <div class="alert alert-success">

           <button type="button" class="close" data-dismiss="alert">
            
           </button>

           <?php echo e(session()->get('message')); ?>


          </div>

          <?php endif; ?> -->

     <form action="<?php echo e(url('editdoctor',$data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
               <label for="dname">Doctor Name</label>
               <input type="text" id="dname" name="name" value="<?php echo e($data->name); ?>">

               <label for="phone">Phone</label>
               <input type="text" id="lname" name="phone" value="<?php echo e($data->phone); ?>">

               <label for="phone">Speciality</label>
               <input type="text" id="lname" name="specility" value="<?php echo e($data->specility); ?>">

                <label for="roomno">Room No</label>
               <input type="text" id="roomno" name="room" value="<?php echo e($data->room); ?>">

               <label for="roomno">Old Image</label>
               <img height="150px" width="150px" src="doctorimage/<?php echo e($data->image); ?>" alt="">

               <label for="image">Change Image</label>
               <input type="file" id="myFile" name="file">

                

               <input type="submit">
  </form>
</div>
</div>
      

    <!-- container-scroller -->
    <!-- plugins:js -->
      <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\hospital\resources\views/admin/update_doctor.blade.php ENDPATH**/ ?>