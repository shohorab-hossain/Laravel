<!DOCTYPE html>
<html lang="en">
  <head>

  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  border: 1px solid black;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
  color:black;
}

tr {
  background-color: #fff;
}
</style>
    
    @include('admin.css')
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->

      @include('admin.sidebar')
      <!-- partial -->
      @include('admin.nav')
        
      <div class="container-fluid ">
<div class="container">        
<table>
  <tr>
    <th>Doctor Name</th>
    <th>Phone</th>
    <th>Speciality</th>
    <th>Room No</th>
    <th>Image</th>
    <th>Delete</th>
    <th>Update</th>

    @foreach($data as $doctor)
<tr>
    <td>{{$doctor->name}}</td>
    <td>{{$doctor->phone}}</td>
    <td>{{$doctor->specility}}</td>
    <td>{{$doctor->room}}</td>
    <td><img height="100px" width="100px" src="doctorimage/{{$doctor->image}}"></td>
    <td><a class="btn btn-danger" onclick="return confirm('are you sure to delete this!!')" href="{{url('deletedoctor',$doctor->id)}}">Delete</a></td>
    <td><a class="btn btn-primary" onclick="return confirm('are you sure to update this!!')" href="{{url('updatedoctor',$doctor->id)}}">Update</a></td>
</tr>
  @endforeach
</table>
      

    <!-- container-scroller -->
    <!-- plugins:js -->
      @include('admin.script')
  </body>
</html>