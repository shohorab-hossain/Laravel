<!DOCTYPE html>
<html lang="en">
  <head>
  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  border: 1px solid black;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
  color:black;
}

tr {
  background-color: #fff;
}
</style>
    @include('admin.css')
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->

      @include('admin.sidebar')
      <!-- partial -->
      @include('admin.nav')
      <div class="container-fluid">
<div class="container">        
<table>
  <tr>
    <th>name</th>
    <th>email</th>
    <th>phone</th>
    <th>Doctor name</th>
    <th>Date</th>
    <th>Message</th>
    <th>Status</th>
    <th>Cancle</th>
    <th>Approved</th>
  </tr>
  @foreach($data as $appoints)
  <tr >
    <td>{{$appoints->name}}</td>
    <td>{{$appoints->email}}</td>
    <td>{{$appoints->phone}}</td>
    <td>{{$appoints->doctor}}</td>
    <td>{{$appoints->date}}</td>
    <td>{{$appoints->message}}</td>
    <td>{{$appoints->status}}</td>
    <td><a class="btn btn-danger" onclick="return confirm('are you sure to delete this!!')" href="{{url('cancle_appoint',$appoints->id)}}">Cancle</a></td>
    <td><a class="btn btn-success" onclick="return confirm('are you sure to Approve this!!')" href="{{url('approve',$appoints->id)}}">Approve</a></td>
  </tr>
  @endforeach
</table>
</div>
</div>

    <!-- container-scroller -->
    <!-- plugins:js -->
      @include('admin.script')
  </body>
</html>