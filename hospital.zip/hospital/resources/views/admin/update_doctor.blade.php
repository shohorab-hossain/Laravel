<!DOCTYPE html>
<html lang="en">
  <head>
    <base href="/public">
  <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
  color:black;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  /* background-color: #f2f2f2; */
  padding: 20px;
}
</style>
    @include('admin.css')
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->

      @include('admin.sidebar')
      <!-- partial -->
      @include('admin.nav')
        
        <div class="container-fluid page-body-wrapper">
      <div class="container">

          @if(session()->has('message'))
           
          <div class="alert alert-success">

           <button type="button" class="close" data-dismiss="alert">
              x
           </button>

           {{session()->get('message')}}

          </div>

          @endif

     <form action="{{url('editdoctor',$data->id)}}" method="post" enctype="multipart/form-data">
        @csrf
        
               <label for="dname">Doctor Name</label>
               <input type="text" id="dname" name="name" value="{{$data->name}}">

               <label for="phone">Phone</label>
               <input type="text" id="lname" name="phone" value="{{$data->phone}}">

               <label for="phone">Speciality</label>
               <input type="text" id="lname" name="specility" value="{{$data->specility}}">

                <label for="roomno">Room No</label>
               <input type="text" id="roomno" name="room" value="{{$data->room}}">

               <label for="roomno">Old Image</label>
               <img height="150px" width="150px" src="doctorimage/{{$data->image}}" alt="">

               <label for="image">Change Image</label>
               <input type="file" id="myFile" name="file">

                

               <input type="submit">
  </form>
</div>
</div>
      

    <!-- container-scroller -->
    <!-- plugins:js -->
      @include('admin.script')
  </body>
</html>