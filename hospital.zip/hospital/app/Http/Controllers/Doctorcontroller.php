<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Doctor;
class Doctorcontroller extends Controller
{
    public function doctor()
    {
        if (Auth::id()) {
            return redirect('home');
       }else{
           $doctor = doctor::all();
           return view('doctor',compact('doctor'));
       }
    }
}
